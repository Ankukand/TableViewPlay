//
//  FirstViewController.swift
//  VertexDemo
//
//  Created by Anku on 23/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

import UIKit

class DatesClass: Codable {
    var strdates: String? = ""
    var isexpaned = false
    var title : String? = ""
}


class FirstViewController: UIViewController
{
    // Data model: These strings will be the data for the table view cells
    
    // cell reuse id (cells that scroll out of view can be reused)
    var boolCollapse = Bool()
    var sectionNumber = NSInteger()
    
    let tableCellReuseIdentifier = "cell"
    let collectionReuseIdentifier = "CollectionCell" // also enter this string as the cell identifier in the storyboard
       // var itemsOpenDates = ["17", "13", "08", "15"]
       // var itemsSectionTitle = ["INCIDENT COUNT", "PSC DEFICIENCY", "NEAR MISS", "INJURY/CREW SICKNESS"]

    
    @IBOutlet var tableViewDates: UITableView!
    @IBOutlet var footerview : UIView!
    @IBOutlet var headerView : UIView!
    @IBOutlet var childview : UIView!
    
    var sectionarray = [DatesClass]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        
        let toppadding = UIApplication.shared.keyWindow!.safeAreaInsets.top
        let bottompadding = UIApplication.shared.keyWindow!.safeAreaInsets.bottom
       
        childview.frame = CGRect(x: 0, y : toppadding, width: self.view.frame.size.width,height : self.view.frame.size.height-(bottompadding+toppadding));
        
        // Do any additional setup after loading the view.
        tableViewDates.delegate = self
        tableViewDates.dataSource = self
        
        
       var dates = DatesClass()
        dates.strdates = "17"
        dates.title = "INCIDENT COUNT"
        sectionarray.append(dates)
        
        dates = DatesClass()
        dates.strdates = "13"
        dates.title = "PSC DEFICIENCY"
        sectionarray.append(dates)
        
        dates = DatesClass()
        dates.strdates = "08"
        dates.title = "NEAR MISS"
        sectionarray.append(dates)
        
        dates = DatesClass()
        dates.strdates = "15"
        dates.title = "INJURY/CREW SICKNESS"
        sectionarray.append(dates)
        
        headerView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: headerView.frame.size.height)
        footerview.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: footerview.frame.size.height)

        tableViewDates.tableHeaderView = headerView
        tableViewDates.tableFooterView = footerview
        
        let nib = UINib(nibName: "CustomHeaderSectionView", bundle: nil)
        tableViewDates.register(nib, forHeaderFooterViewReuseIdentifier: "CustomHeaderSectionView")
    }
}

extension FirstViewController : UITableViewDelegate,UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionarray.count
    }
    
    func tableView(_ tableView: UITableView,
           numberOfRowsInSection section: Int) -> Int {
//        if section != sectionNumber && boolCollapse == false {
//           return 0
//        }
           return 1
       }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{

        var cell = tableView.dequeueReusableCell(withIdentifier: tableCellReuseIdentifier) as? TableViewCell
        if cell == nil {
            cell = (Bundle.main.loadNibNamed("TableViewCell", owner: self, options: nil)! [0] as! TableViewCell)
        }
        let dates = sectionarray[indexPath.section]
        cell?.custom?.tag = indexPath.section
        cell?.lblOpenDate.text = dates.strdates
        cell?.custom?.collectionViewDates.reloadData()
        return cell!
       }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

            let dates = sectionarray[section]
            let headerView = tableViewDates.dequeueReusableHeaderFooterView(withIdentifier: "CustomHeaderSectionView") as! CustomHeaderSectionView
        headerView.lblSectionInciCount.text = dates.strdates
            headerView.lblSectionTitle.text = dates.title
        headerView.sectionbtn.addTarget(self,
                                          action: #selector(self.hideSection(sender:)),
                                           for: .touchUpInside)
        headerView.sectionbtn.tag = section
            return headerView
    }
    @objc
    private func hideSection(sender: UIButton) {
 
        let dates = sectionarray[sender.tag]
        if dates.isexpaned
        {
            dates.isexpaned = false
        }
        else
        {
            dates.isexpaned = true
        }
        
        tableViewDates.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

            return 65
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        let dates = sectionarray[indexPath.section]
        if dates.isexpaned {
            return 95
        }
        return 0
    }
       
       // method to run when table view cell is tapped
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           print("You tapped cell number \(indexPath.row).")
       }
}

//
//  TabBarController.swift
//  VertexDemo
//
//  Created by Anku on 23/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

class ImageClass {
    var selectedimage = ""
    var unselectedimage = ""
    var title = ""
    
}

import UIKit

class TabBarController: UITabBarController {

     let selectedColor = UIColor.blue
        let deselectedColor = UIColor.gray
        
        var tabBarImages = [ImageClass]()
//        let tabBarTitle = [
//            "DASHBOARD",
//            "PMS",
//           "SHEQ",
//            "PROCUREMENT",
//            "DMS"
//        ]
        
        override func viewDidLoad() {
            
            view.backgroundColor = .gray
            self.delegate = self
            tabBar.isTranslucent = true
            
//            let tabBarImages = [
//                UIImage(named: "DashboardSel")!,
//                UIImage(named: "PMSSel")!,
//                UIImage(named: "SHEQSel")!,
//                UIImage(named: "ProcurementSel")!,
//                UIImage(named: "DMSSel")!
//            ]
            
            var imagecl = ImageClass()
            imagecl.selectedimage = "DashboardSel"
            imagecl.unselectedimage = "DashboardUnsel"
            imagecl.title = "DASHBOARD"
            
            tabBarImages.append(imagecl)
            
             imagecl = ImageClass()
            imagecl.selectedimage = "PMSSel"
            imagecl.unselectedimage = "PMSUnsel"
            imagecl.title = "PMS"
            
            tabBarImages.append(imagecl)
            
             imagecl = ImageClass()
            imagecl.selectedimage = "SHEQSel"
            imagecl.unselectedimage = "SHEQUnsel"
            imagecl.title = "SHEQ"
            
            tabBarImages.append(imagecl)
            
             imagecl = ImageClass()
            imagecl.selectedimage = "ProcurementSel"
            imagecl.unselectedimage = "ProcurementUnsel"
            imagecl.title = "PROCUREMENT"
            
            tabBarImages.append(imagecl)
            
             imagecl = ImageClass()
            imagecl.selectedimage = "DMSSel"
            imagecl.unselectedimage = "DMSUnsel"
            imagecl.title = "DMS"
            
            tabBarImages.append(imagecl)
            
            
            
            
          //  tabBar.tintColor = deselectedColor
          //  tabBar.unselectedItemTintColor = deselectedColor
            tabBar.barTintColor = UIColor.white.withAlphaComponent(0.92)
            tabBar.itemSpacing = 10.0
            tabBar.itemWidth = 76.0
            tabBar.itemPositioning = .centered
            setUp()
            self.selectPage(at: 0)
        }
        
        private func setUp() {
            
            guard let centerPageViewController = createCenterPageViewController() else { return }
            
            var controllers: [UIViewController] = []
            controllers.append(centerPageViewController)
            controllers.append(createPlaceholderViewController(forIndex: 1))
            controllers.append(createPlaceholderViewController(forIndex: 2))
            controllers.append(createPlaceholderViewController(forIndex: 3))
            controllers.append(createPlaceholderViewController(forIndex: 4))
            setViewControllers(controllers, animated: false)
            selectedViewController = centerPageViewController
        }
        
    private func selectedtabbarItem(at index: Int) -> UITabBarItem {
        
        let imageclass = self.tabBarImages[index]
        let tabBarItem = UITabBarItem()
        tabBarItem.title = imageclass.title
        tabBarItem.image = UIImage(named: imageclass.selectedimage)?.withRenderingMode(.alwaysOriginal)
   //     tabBarItem.selectedImage = UIImage(named: imageclass.selectedimage)?.withRenderingMode(.alwaysOriginal)
    
        let selectedItem = [NSAttributedString.Key.foregroundColor: UIColor(red: 38/255, green: 85/255, blue: 135/255, alpha: 1)]
        tabBarItem.setTitleTextAttributes(selectedItem, for: .normal)
    
        return tabBarItem
    }
    
    private func unselectedtabbarItem(at index: Int) -> UITabBarItem {
           
        let imageclass = self.tabBarImages[index]
        let tabBarItem = UITabBarItem()
        tabBarItem.title = imageclass.title
        tabBarItem.image = UIImage(named: imageclass.unselectedimage)?.withRenderingMode(.alwaysOriginal)
      //  tabBarItem.selectedImage = UIImage(named: imageclass.selectedimage)?.withRenderingMode(.alwaysOriginal)
           let unselectedItem = [NSAttributedString.Key.foregroundColor: UIColor.gray]
           tabBarItem.setTitleTextAttributes(unselectedItem, for: .normal)
           return tabBarItem
       }
    
        private func selectPage(at index: Int) {
            guard let viewController = self.viewControllers?[index] else { return }
            self.handleTabbarItemChange(viewController: viewController)
            guard let PageViewController = (self.viewControllers?[0] as? PageViewController) else { return }
            PageViewController.selectPage(at: index)
            
            for i in 0..<self.viewControllers!.count {
                let controller = self.viewControllers![i]
                if i == index
                {
                    controller.tabBarItem = selectedtabbarItem(at: i)
                }
                else
                {
                    controller.tabBarItem = unselectedtabbarItem(at: i)
                }
            }
        }
        
        private func createPlaceholderViewController(forIndex index: Int) -> UIViewController {
            let emptyViewController = UIViewController()
            emptyViewController.tabBarItem = tabbarItem(at: index)
            emptyViewController.view.tag = index
            return emptyViewController
        }
        
        private func createCenterPageViewController() -> UIPageViewController? {
            
            let firstViewController = FirstViewController(nibName: "FirstViewController", bundle: nil)
            let secondViewController = SecondViewController(nibName: "SecondViewController", bundle: nil)
            let thirdViewController = ThirdViewController(nibName: "ThirdViewController", bundle: nil)
            let fourthViewController = FourthViewController(nibName: "FourthViewController", bundle: nil)
                       let fifthViewController = FifthViewController(nibName: "FifthViewController", bundle: nil)
            
            firstViewController.view.tag = 0
            secondViewController.view.tag = 1
            thirdViewController.view.tag = 2
            fourthViewController.view.tag = 3
            fifthViewController.view.tag = 4
            
            let pageViewController = PageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
            pageViewController.pages = [firstViewController, secondViewController, thirdViewController,fourthViewController, fifthViewController]
            pageViewController.tabBarItem = tabbarItem(at: 0)
            pageViewController.view.tag = 0
            pageViewController.swipeDelegate = self
            
            return pageViewController
        }
        
        private func tabbarItem(at index: Int) -> UITabBarItem {
        //    let tabBarItem = UITabBarItem(title: self.tabBarTitle[index], image: self.tabBarImages[index], selectedImage: nil)
            
          //  let imageclass = self.tabBarImages[index]
            let tabBarItem = UITabBarItem()
          //  tabBarItem.title = imageclass.title
           // tabBarItem.image = UIImage(named: imageclass.unselectedimage)
           // tabBarItem.selectedImage = UIImage(named: imageclass.selectedimage)
            
         //   let unselectedItem = [NSAttributedString.Key.foregroundColor: UIColor.gray]
          //  let selectedItem = [NSAttributedString.Key.foregroundColor: UIColor.purple]
            
          //  tabBarItem.setTitleTextAttributes(unselectedItem, for: .normal)
            //tabBarItem.setTitleTextAttributes(selectedItem, for: .selected)
          
            return tabBarItem
        }
   
        
        private func handleTabbarItemChange(viewController: UIViewController) {
            guard let viewControllers = self.viewControllers else { return }
            let selectedIndex = viewController.view.tag
    
            for i in 0..<self.viewControllers!.count {
                let controller = self.viewControllers![i]
                if i == selectedIndex
                {
                    controller.tabBarItem = selectedtabbarItem(at: i)
                }
                else
                {
                    controller.tabBarItem = unselectedtabbarItem(at: i)
                }
              
            }
        
           
        }
    }

    extension TabBarController: UITabBarControllerDelegate, PageViewControllerDelegate {
        
        func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
            self.selectPage(at: viewController.view.tag)
            return false
        }
        
        func pageDidSwipe(to index: Int) {
            guard let viewController = self.viewControllers?[index] else { return }
            self.handleTabbarItemChange(viewController: viewController)
        }
        
    }

//
//  AppDelegate.swift
//  VertexDemo
//
//  Created by Anku on 23/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var navigation : UINavigationController!
        func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
            NSLog("didFinishLaunchingWithOptions");
            self.window = UIWindow(frame: CGRect(x: 0, y: 0, width:UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height))
             self.window!.makeKeyAndVisible()
            
            let viewcontroller  = TabBarController(nibName: "TabBarController", bundle: nil)
            
            navigation = UINavigationController(rootViewController: viewcontroller)
            navigation.navigationBar.isHidden  = true
             self.window!.rootViewController = navigation
            return true
        }

        func applicationWillResignActive(_ application: UIApplication) {
            NSLog("applicationWillResignActive");
        }

        func applicationDidEnterBackground(_ application: UIApplication) {
            NSLog("applicationDidEnterBackground");
        }

        func applicationWillEnterForeground(_ application: UIApplication) {
            NSLog("applicationWillEnterForeground");
        }

        func applicationDidBecomeActive(_ application: UIApplication) {
            NSLog("applicationDidBecomeActive");
        }

        func applicationWillTerminate(_ application: UIApplication) {
            NSLog("applicationWillTerminate");
        }

    }

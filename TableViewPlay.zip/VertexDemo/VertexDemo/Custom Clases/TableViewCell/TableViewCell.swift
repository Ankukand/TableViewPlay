//
//  TableViewCell.swift
//  VertexDemo
//
//  Created by Anku on 23/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell
{
    @IBOutlet var custom : CustomView?
    @IBOutlet var lblOpenDate : UILabel!
 
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
}
    
   
    
    

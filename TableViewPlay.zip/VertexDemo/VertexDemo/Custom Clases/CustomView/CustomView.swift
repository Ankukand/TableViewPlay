//
//  CustomView.swift
//  VertexDemo
//
//  Created by Anku on 24/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

import UIKit

class CustomView: UIView,UICollectionViewDelegate,UICollectionViewDataSource {

    let collectionReuseIdentifier = "CustomCollectionDatesCell"
    @IBOutlet var collectionViewDates: UICollectionView!
    @IBOutlet var lblOpenDate: UILabel!
   var arrayDates = [["20", "30", "05"],["10", "23", "19"],
                     ["20", "17", "02"],["37", "10", "01"],
                     ["30", "20", "11"]]
 
    var arrayImageDates = ["Last-3-months", "last-month", "Last-year"]
    
    override func awakeFromNib() {
               super.awakeFromNib()
               
              
           let flowLayout = UICollectionViewFlowLayout()
           flowLayout.scrollDirection = .horizontal
           flowLayout.itemSize = CGSize(width: 80 , height: 80)
           flowLayout.minimumLineSpacing = 0.0
           flowLayout.minimumInteritemSpacing = 5.0
           collectionViewDates.collectionViewLayout = flowLayout
           
        
           //register the xib for collection view cell
           let cellNib = UINib(nibName: "CustomDatesCollectionViewCell", bundle: nil)
          collectionViewDates.register(cellNib, forCellWithReuseIdentifier: collectionReuseIdentifier)
           
           }
           
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
       }
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionViewDates.dequeueReusableCell(withReuseIdentifier: collectionReuseIdentifier, for: indexPath) as? CustomDatesCollectionViewCell
        let arr = arrayDates [self.tag]
        cell?.lblDates.text = arr[indexPath.item]
         
           
           cell?.imgViewDate.image = UIImage(named: arrayImageDates[indexPath.row])
           return cell!
       }
    
    
    
}



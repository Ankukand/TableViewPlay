//
//  CustomHeaderSectionView.swift
//  VertexDemo
//
//  Created by Anku on 24/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

import UIKit

class CustomHeaderSectionView: UITableViewHeaderFooterView {
    @IBOutlet var lblSectionInciCount: UILabel!
     @IBOutlet var lblSectionTitle: UILabel!
    @IBOutlet var sectionbtn: UIButton!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}

//
//  CustomDatesCollectionViewCell.swift
//  VertexDemo
//
//  Created by Anku on 23/06/20.
//  Copyright © 2020 Anku. All rights reserved.
//

import UIKit

class CustomDatesCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imgViewDate: UIImageView!
    @IBOutlet var lblDates: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

}
